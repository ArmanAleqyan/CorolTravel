/**
 * @prettier
 */
const jsonPointerGenerator = () => "/a/b/c"

export default jsonPointerGenerator
