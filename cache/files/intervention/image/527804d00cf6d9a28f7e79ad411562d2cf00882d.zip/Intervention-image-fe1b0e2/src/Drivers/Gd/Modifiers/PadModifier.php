<?php

declare(strict_types=1);

namespace Intervention\Image\Drivers\Gd\Modifiers;

class PadModifier extends ContainModifier
{
}
