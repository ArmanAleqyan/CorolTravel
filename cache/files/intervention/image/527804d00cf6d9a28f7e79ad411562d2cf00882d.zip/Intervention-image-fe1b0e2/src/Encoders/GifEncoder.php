<?php

declare(strict_types=1);

namespace Intervention\Image\Encoders;

use Intervention\Image\Interfaces\SpecializableInterface;

class GifEncoder extends SpecializableEncoder implements SpecializableInterface
{
}
