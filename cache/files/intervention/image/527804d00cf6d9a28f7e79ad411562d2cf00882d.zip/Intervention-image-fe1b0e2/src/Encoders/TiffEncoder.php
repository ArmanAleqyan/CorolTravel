<?php

declare(strict_types=1);

namespace Intervention\Image\Encoders;

use Intervention\Image\Interfaces\SpecializableInterface;

class TiffEncoder extends SpecializableEncoder implements SpecializableInterface
{
}
